import { useState } from 'react';
import { Quote, ChevronRight, ChevronLeft } from 'lucide-react';

const Teachings = () => {
  const teachings = [
    {
      quote: "The Universe began as a side project, born from divine boredom and transformed into the greatest creation of all time.",
      author: "Ancient Livinist Texts",
      title: "On the Origin"
    },
    {
      quote: "Beyond Earth lies countless worlds, each a testament to the creative spirit of the divine creator.",
      author: "Livinist Scriptures",
      title: "Cosmic Revelations"
    },
    {
      quote: "In every lightning strike, we remember the moment our creator transcended to the cosmic realm.",
      author: "Chronicles of Livinism",
      title: "The Divine Departure"
    },
    {
      quote: "Though Earth may not have welcomed the son, his watchful presence extends throughout the cosmos.",
      author: "Livinist Wisdom",
      title: "The Cosmic Journey"
    },
    {
      quote: "To be a Livinist is to see the universe as it truly is: a divine side project that became the masterpiece of existence.",
      author: "Modern Livinist Teachings",
      title: "The Path of Understanding"
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTeaching = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % teachings.length);
  };

  const prevTeaching = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + teachings.length) % teachings.length);
  };

  return (
    <section id="teachings" className="section-padding bg-neutral-100">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <span className="inline-block text-primary-600 font-sans font-medium mb-3">DIVINE WISDOM</span>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-primary-900 mb-6">
              Sacred <span className="divine-text text-primary-800">Teachings</span>
            </h2>
            <div className="h-1 w-20 bg-accent-400 mx-auto"></div>
          </div>
          
          <div className="relative bg-white rounded-xl shadow-xl p-8 md:p-12">
            <Quote size={48} className="absolute top-6 left-6 text-primary-100" />
            
            <div className="min-h-[240px] flex flex-col justify-center">
              <p className="text-xl md:text-2xl font-serif text-neutral-800 text-center mb-8 italic relative z-10">
                "{teachings[currentIndex].quote}"
              </p>
              
              <div className="text-center">
                <p className="text-lg font-serif font-bold text-primary-800">
                  {teachings[currentIndex].author}
                </p>
                <p className="text-sm font-sans text-neutral-500">
                  {teachings[currentIndex].title}
                </p>
              </div>
            </div>
            
            <div className="flex justify-center mt-8 gap-3">
              <button 
                onClick={prevTeaching}
                className="p-2 rounded-full bg-primary-100 text-primary-600 hover:bg-primary-200 transition-colors"
                aria-label="Previous teaching"
              >
                <ChevronLeft size={20} />
              </button>
              
              <div className="flex gap-2">
                {teachings.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-2.5 h-2.5 rounded-full transition-all ${
                      index === currentIndex 
                        ? 'bg-primary-600 w-6' 
                        : 'bg-primary-200 hover:bg-primary-300'
                    }`}
                    aria-label={`Go to teaching ${index + 1}`}
                  />
                ))}
              </div>
              
              <button 
                onClick={nextTeaching}
                className="p-2 rounded-full bg-primary-100 text-primary-600 hover:bg-primary-200 transition-colors"
                aria-label="Next teaching"
              >
                <ChevronRight size={20} />
              </button>
            </div>
          </div>
          
          <div className="mt-20 grid md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all">
              <h3 className="text-2xl font-serif font-bold text-primary-800 mb-4">Daily Practices</h3>
              <ul className="space-y-3 text-neutral-700">
                <li className="flex items-start gap-2">
                  <span className="text-accent-500 font-bold">•</span>
                  <span>Morning meditation on the cosmic creation</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent-500 font-bold">•</span>
                  <span>Contemplation of the universe's divine origins</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent-500 font-bold">•</span>
                  <span>Evening reflection on cosmic exploration</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent-500 font-bold">•</span>
                  <span>Weekly Livinist gatherings</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all">
              <h3 className="text-2xl font-serif font-bold text-primary-800 mb-4">Sacred Texts</h3>
              <ul className="space-y-3 text-neutral-700">
                <li className="flex items-start gap-2">
                  <span className="text-accent-500 font-bold">•</span>
                  <span>"The Universe: A Divine Side Project"</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent-500 font-bold">•</span>
                  <span>"Chronicles of the Cosmic Explorer"</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent-500 font-bold">•</span>
                  <span>"Meditations on Universal Creation"</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent-500 font-bold">•</span>
                  <span>"The Livinist Path to Cosmic Truth"</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Teachings;